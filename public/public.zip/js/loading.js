export function showLoading() {
    $(".loading").modal("show");
}
export function closeLoading() {
    $(".loading").modal("toggle");
}
